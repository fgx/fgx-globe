-- 3dvia.com   --

The zip file Boeing 777-200ER.3ds.zip contains the following files :
- readme.txt
- Boeing 777-200ER.3ds
- 04.jpg


-- Model information --

Model Name : Boeing 777-200ER
Author : adrian19
Publisher : adrian19

You can view this model here :
http://www.3dvia.com/content/97BFB38D9FB18395
More models about this author :
http://www.3dvia.com/adrian19


-- Attached license --

A license is attached to the Boeing 777-200ER model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
