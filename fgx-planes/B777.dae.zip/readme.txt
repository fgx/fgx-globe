-- 3dvia.com   --

The zip file B777.dae.zip contains the following files :
- readme.txt
- B777.dae


-- Model information --

Model Name : Boeing 777-300
Author : Mr Planet
Publisher : Mr_Planet

You can view this model here :
http://www.3dvia.com/content/803963B6889AACBE
More models about this author :
http://www.3dvia.com/Mr_Planet


-- Attached license --

A license is attached to the Boeing 777-300 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
